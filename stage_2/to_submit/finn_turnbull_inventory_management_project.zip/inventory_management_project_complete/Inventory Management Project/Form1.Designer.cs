﻿namespace Inventory_Management_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tab_control_1 = new System.Windows.Forms.TabControl();
            this.Production = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.insertContainer = new System.Windows.Forms.ComboBox();
            this.gustorageBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.gu_tables = new Inventory_Management_Project.gu_tables();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.insertAlcohol = new System.Windows.Forms.ComboBox();
            this.gualcaholBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.insertGyle = new System.Windows.Forms.TextBox();
            this.insertNumberContainers = new System.Windows.Forms.TextBox();
            this.submitRecordsInsert = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.insertLocation = new System.Windows.Forms.ComboBox();
            this.gulocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productionViewBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.gu_views = new Inventory_Management_Project.gu_views();
            this.Tab2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.submitRecordsBottle = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.selectGyleBottle = new System.Windows.Forms.ComboBox();
            this.packagingBottlingSelectViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.updateContainer = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.updateLocationBottle = new System.Windows.Forms.ComboBox();
            this.gulocationBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.updateDate = new System.Windows.Forms.DateTimePicker();
            this.updateNumberContainers = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.setEndNumber = new System.Windows.Forms.TextBox();
            this.submitRecordsLabel = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.setDutyStatus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.selectGyleLabel = new System.Windows.Forms.ComboBox();
            this.packagingDutySelectViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gu_views1 = new Inventory_Management_Project.gu_views();
            this.setStartNumber = new System.Windows.Forms.TextBox();
            this.setStaffID = new System.Windows.Forms.ComboBox();
            this.gustaffBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label23 = new System.Windows.Forms.Label();
            this.updateLocationLabel = new System.Windows.Forms.ComboBox();
            this.gulocationBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filledDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateFilledDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packagingStockViewBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packagingDutyRecordsViewBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.Sales = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.deleteRecords = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.selectGyleSell = new System.Windows.Forms.ComboBox();
            this.salesAvailableViewBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.gu_views3 = new Inventory_Management_Project.gu_views();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.Gyle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesAvailableViewBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.salesAvailableViewBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.gu_views2 = new Inventory_Management_Project.gu_views();
            this.salesAvailableViewBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingDutySelectViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gubatchBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.gubatchBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingStockViewBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.gustorageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gualcaholBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gubatchBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productionViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingStockViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingDutyRecordsViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.salesAvailableViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.productionViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.packagingViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.packagingDutyRecordsViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salesAvailableViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salesSoldViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gubatchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gustorageBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingStockViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.packagingStockViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.packagingStockViewTableAdapter();
            this.packagingDutyRecordsViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.packagingDutyRecordsViewTableAdapter();
            this.salesAvailableViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.salesAvailableViewTableAdapter();
            this.productionViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.productionViewTableAdapter();
            this.gu_alcaholTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_alcaholTableAdapter();
            this.gu_storageTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_storageTableAdapter();
            this.gu_locationTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_locationTableAdapter();
            this.gu_batchTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_batchTableAdapter();
            this.gubatchBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.fKgubatchgustorageBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gubatchBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.fKgubatchgulocationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gu_staffTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_staffTableAdapter();
            this.gutablesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gudutyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gu_dutyTableAdapter = new Inventory_Management_Project.gu_tablesTableAdapters.gu_dutyTableAdapter();
            this.gubatchBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.gustorageBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.packagingDutySelectViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.packagingDutySelectViewTableAdapter();
            this.packagingBottlingSelectViewTableAdapter = new Inventory_Management_Project.gu_viewsTableAdapters.packagingBottlingSelectViewTableAdapter();
            this.tab_control_1.SuspendLayout();
            this.Production.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_tables)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gualcaholBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views)).BeginInit();
            this.Tab2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagingBottlingSelectViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutySelectViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustaffBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource3)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource2)).BeginInit();
            this.Sales.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views3)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutySelectViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gualcaholBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesSoldViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKgubatchgustorageBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKgubatchgulocationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gutablesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gudutyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // tab_control_1
            // 
            this.tab_control_1.Controls.Add(this.Production);
            this.tab_control_1.Controls.Add(this.Tab2);
            this.tab_control_1.Controls.Add(this.Sales);
            this.tab_control_1.Location = new System.Drawing.Point(3, 3);
            this.tab_control_1.Name = "tab_control_1";
            this.tab_control_1.SelectedIndex = 0;
            this.tab_control_1.Size = new System.Drawing.Size(777, 547);
            this.tab_control_1.TabIndex = 0;
            // 
            // Production
            // 
            this.Production.Controls.Add(this.tabControl1);
            this.Production.Location = new System.Drawing.Point(4, 22);
            this.Production.Name = "Production";
            this.Production.Padding = new System.Windows.Forms.Padding(3);
            this.Production.Size = new System.Drawing.Size(769, 521);
            this.Production.TabIndex = 0;
            this.Production.Text = "Production";
            this.Production.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.ItemSize = new System.Drawing.Size(42, 18);
            this.tabControl1.Location = new System.Drawing.Point(6, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(757, 512);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tableLayoutPanel1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(749, 486);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Insert";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.Controls.Add(this.insertContainer, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.insertAlcohol, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.insertGyle, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.insertNumberContainers, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.submitRecordsInsert, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.insertLocation, 1, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66611F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66611F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66611F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66611F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66944F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66611F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(746, 483);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // insertContainer
            // 
            this.insertContainer.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.insertContainer.DataSource = this.gustorageBindingSource2;
            this.insertContainer.DisplayMember = "container";
            this.insertContainer.DropDownHeight = 120;
            this.insertContainer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.insertContainer.FormattingEnabled = true;
            this.insertContainer.IntegralHeight = false;
            this.insertContainer.ItemHeight = 13;
            this.insertContainer.Location = new System.Drawing.Point(450, 189);
            this.insertContainer.MaxDropDownItems = 100;
            this.insertContainer.Name = "insertContainer";
            this.insertContainer.Size = new System.Drawing.Size(204, 21);
            this.insertContainer.TabIndex = 8;
            this.insertContainer.ValueMember = "container_id";
            // 
            // gustorageBindingSource2
            // 
            this.gustorageBindingSource2.DataMember = "gu_storage";
            this.gustorageBindingSource2.DataSource = this.gu_tables;
            // 
            // gu_tables
            // 
            this.gu_tables.DataSetName = "gu_tables";
            this.gu_tables.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(441, 80);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select alcohol to insert:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(441, 80);
            this.label2.TabIndex = 1;
            this.label2.Text = "Assign gyle number:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(441, 80);
            this.label4.TabIndex = 3;
            this.label4.Text = "Container type:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(441, 80);
            this.label5.TabIndex = 4;
            this.label5.Text = "Number of containers:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // insertAlcohol
            // 
            this.insertAlcohol.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.insertAlcohol.DataSource = this.gualcaholBindingSource1;
            this.insertAlcohol.DisplayMember = "drink_type";
            this.insertAlcohol.DropDownHeight = 120;
            this.insertAlcohol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.insertAlcohol.FormattingEnabled = true;
            this.insertAlcohol.IntegralHeight = false;
            this.insertAlcohol.ItemHeight = 13;
            this.insertAlcohol.Location = new System.Drawing.Point(450, 29);
            this.insertAlcohol.MaxDropDownItems = 100;
            this.insertAlcohol.Name = "insertAlcohol";
            this.insertAlcohol.Size = new System.Drawing.Size(204, 21);
            this.insertAlcohol.TabIndex = 5;
            this.insertAlcohol.ValueMember = "drink_id";
            // 
            // gualcaholBindingSource1
            // 
            this.gualcaholBindingSource1.DataMember = "gu_alcahol";
            this.gualcaholBindingSource1.DataSource = this.gu_tables;
            // 
            // insertGyle
            // 
            this.insertGyle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.insertGyle.Location = new System.Drawing.Point(450, 110);
            this.insertGyle.Name = "insertGyle";
            this.insertGyle.Size = new System.Drawing.Size(204, 20);
            this.insertGyle.TabIndex = 6;
            // 
            // insertNumberContainers
            // 
            this.insertNumberContainers.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.insertNumberContainers.Location = new System.Drawing.Point(450, 270);
            this.insertNumberContainers.Name = "insertNumberContainers";
            this.insertNumberContainers.Size = new System.Drawing.Size(204, 20);
            this.insertNumberContainers.TabIndex = 9;
            // 
            // submitRecordsInsert
            // 
            this.submitRecordsInsert.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submitRecordsInsert.Location = new System.Drawing.Point(450, 426);
            this.submitRecordsInsert.Name = "submitRecordsInsert";
            this.submitRecordsInsert.Size = new System.Drawing.Size(204, 30);
            this.submitRecordsInsert.TabIndex = 10;
            this.submitRecordsInsert.Text = "Submit Records";
            this.submitRecordsInsert.UseVisualStyleBackColor = true;
            this.submitRecordsInsert.Click += new System.EventHandler(this.submitRecordsInsert_Click);
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 320);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(441, 80);
            this.label15.TabIndex = 11;
            this.label15.Text = "Storage location:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // insertLocation
            // 
            this.insertLocation.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.insertLocation.DataSource = this.gulocationBindingSource;
            this.insertLocation.DisplayMember = "storage_location";
            this.insertLocation.DropDownHeight = 120;
            this.insertLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.insertLocation.FormattingEnabled = true;
            this.insertLocation.IntegralHeight = false;
            this.insertLocation.ItemHeight = 13;
            this.insertLocation.Location = new System.Drawing.Point(450, 349);
            this.insertLocation.MaxDropDownItems = 100;
            this.insertLocation.Name = "insertLocation";
            this.insertLocation.Size = new System.Drawing.Size(204, 21);
            this.insertLocation.TabIndex = 12;
            this.insertLocation.ValueMember = "location_id";
            // 
            // gulocationBindingSource
            // 
            this.gulocationBindingSource.DataMember = "gu_location";
            this.gulocationBindingSource.DataSource = this.gu_tables;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridView1);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(749, 486);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "View";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40});
            this.dataGridView1.DataSource = this.productionViewBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(746, 483);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Gyle";
            this.dataGridViewTextBoxColumn35.HeaderText = "Gyle";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Drink";
            this.dataGridViewTextBoxColumn36.HeaderText = "Drink";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "ABV";
            this.dataGridViewTextBoxColumn37.HeaderText = "ABV";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn38.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Container";
            this.dataGridViewTextBoxColumn39.HeaderText = "Container";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Size (ml)";
            this.dataGridViewTextBoxColumn40.HeaderText = "Size (ml)";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            // 
            // productionViewBindingSource2
            // 
            this.productionViewBindingSource2.DataMember = "productionView";
            this.productionViewBindingSource2.DataSource = this.gu_views;
            // 
            // gu_views
            // 
            this.gu_views.DataSetName = "gu_views";
            this.gu_views.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Tab2
            // 
            this.Tab2.Controls.Add(this.tabControl2);
            this.Tab2.Location = new System.Drawing.Point(4, 22);
            this.Tab2.Name = "Tab2";
            this.Tab2.Padding = new System.Windows.Forms.Padding(3);
            this.Tab2.Size = new System.Drawing.Size(769, 521);
            this.Tab2.TabIndex = 1;
            this.Tab2.Text = "Packaging";
            this.Tab2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Location = new System.Drawing.Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(757, 512);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(749, 486);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bottle";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel3.Controls.Add(this.submitRecordsBottle, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.selectGyleBottle, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.updateContainer, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label13, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label14, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.label16, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.updateLocationBottle, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.updateDate, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.updateNumberContainers, 1, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 6;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.67084F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66583F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66583F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66583F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66583F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66583F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(746, 483);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // submitRecordsBottle
            // 
            this.submitRecordsBottle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submitRecordsBottle.Location = new System.Drawing.Point(450, 426);
            this.submitRecordsBottle.Name = "submitRecordsBottle";
            this.submitRecordsBottle.Size = new System.Drawing.Size(209, 30);
            this.submitRecordsBottle.TabIndex = 10;
            this.submitRecordsBottle.Text = "Submit Records";
            this.submitRecordsBottle.UseVisualStyleBackColor = true;
            this.submitRecordsBottle.Click += new System.EventHandler(this.submitRecordsBottle_Click);
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(441, 80);
            this.label22.TabIndex = 14;
            this.label22.Text = "Select gyle number:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // selectGyleBottle
            // 
            this.selectGyleBottle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.selectGyleBottle.DataSource = this.packagingBottlingSelectViewBindingSource;
            this.selectGyleBottle.DisplayMember = "gyle";
            this.selectGyleBottle.DropDownHeight = 120;
            this.selectGyleBottle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectGyleBottle.FormattingEnabled = true;
            this.selectGyleBottle.IntegralHeight = false;
            this.selectGyleBottle.ItemHeight = 13;
            this.selectGyleBottle.Location = new System.Drawing.Point(450, 29);
            this.selectGyleBottle.MaxDropDownItems = 100;
            this.selectGyleBottle.Name = "selectGyleBottle";
            this.selectGyleBottle.Size = new System.Drawing.Size(209, 21);
            this.selectGyleBottle.TabIndex = 15;
            this.selectGyleBottle.ValueMember = "gyle";
            // 
            // packagingBottlingSelectViewBindingSource
            // 
            this.packagingBottlingSelectViewBindingSource.DataMember = "packagingBottlingSelectView";
            this.packagingBottlingSelectViewBindingSource.DataSource = this.gu_views;
            // 
            // updateContainer
            // 
            this.updateContainer.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateContainer.DataSource = this.gustorageBindingSource2;
            this.updateContainer.DisplayMember = "container";
            this.updateContainer.DropDownHeight = 120;
            this.updateContainer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.updateContainer.FormattingEnabled = true;
            this.updateContainer.IntegralHeight = false;
            this.updateContainer.ItemHeight = 13;
            this.updateContainer.Location = new System.Drawing.Point(450, 109);
            this.updateContainer.MaxDropDownItems = 100;
            this.updateContainer.Name = "updateContainer";
            this.updateContainer.Size = new System.Drawing.Size(209, 21);
            this.updateContainer.TabIndex = 16;
            this.updateContainer.ValueMember = "container_id";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(441, 80);
            this.label7.TabIndex = 19;
            this.label7.Text = "Container type:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(441, 80);
            this.label13.TabIndex = 20;
            this.label13.Text = "Number of items:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 240);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(441, 80);
            this.label14.TabIndex = 21;
            this.label14.Text = "Date filled:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 320);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(441, 80);
            this.label16.TabIndex = 22;
            this.label16.Text = "Storage location:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // updateLocationBottle
            // 
            this.updateLocationBottle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateLocationBottle.DataSource = this.gulocationBindingSource1;
            this.updateLocationBottle.DisplayMember = "storage_location";
            this.updateLocationBottle.DropDownHeight = 120;
            this.updateLocationBottle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.updateLocationBottle.FormattingEnabled = true;
            this.updateLocationBottle.IntegralHeight = false;
            this.updateLocationBottle.ItemHeight = 13;
            this.updateLocationBottle.Location = new System.Drawing.Point(450, 349);
            this.updateLocationBottle.MaxDropDownItems = 100;
            this.updateLocationBottle.Name = "updateLocationBottle";
            this.updateLocationBottle.Size = new System.Drawing.Size(209, 21);
            this.updateLocationBottle.TabIndex = 23;
            this.updateLocationBottle.ValueMember = "location_id";
            // 
            // gulocationBindingSource1
            // 
            this.gulocationBindingSource1.DataMember = "gu_location";
            this.gulocationBindingSource1.DataSource = this.gu_tables;
            // 
            // updateDate
            // 
            this.updateDate.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateDate.CustomFormat = "yyyy MMM dd";
            this.updateDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.updateDate.Location = new System.Drawing.Point(450, 270);
            this.updateDate.MinDate = new System.DateTime(2018, 1, 1, 0, 0, 0, 0);
            this.updateDate.Name = "updateDate";
            this.updateDate.Size = new System.Drawing.Size(200, 20);
            this.updateDate.TabIndex = 24;
            // 
            // updateNumberContainers
            // 
            this.updateNumberContainers.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateNumberContainers.Location = new System.Drawing.Point(450, 190);
            this.updateNumberContainers.Name = "updateNumberContainers";
            this.updateNumberContainers.Size = new System.Drawing.Size(209, 20);
            this.updateNumberContainers.TabIndex = 25;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tableLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(749, 486);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Label";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.setEndNumber, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.submitRecordsLabel, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.setDutyStatus, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.selectGyleLabel, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.setStartNumber, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.setStaffID, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label23, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.updateLocationLabel, 1, 5);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2887F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2844F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2844F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2844F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2844F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2893F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.2844F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(746, 483);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(441, 68);
            this.label9.TabIndex = 2;
            this.label9.Text = "Staff member:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(441, 68);
            this.label10.TabIndex = 3;
            this.label10.Text = "Duty stamp start number:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 205);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(441, 68);
            this.label11.TabIndex = 4;
            this.label11.Text = "Duty stamp end number:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // setEndNumber
            // 
            this.setEndNumber.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.setEndNumber.Location = new System.Drawing.Point(450, 229);
            this.setEndNumber.Name = "setEndNumber";
            this.setEndNumber.Size = new System.Drawing.Size(209, 20);
            this.setEndNumber.TabIndex = 9;
            // 
            // submitRecordsLabel
            // 
            this.submitRecordsLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.submitRecordsLabel.Location = new System.Drawing.Point(450, 431);
            this.submitRecordsLabel.Name = "submitRecordsLabel";
            this.submitRecordsLabel.Size = new System.Drawing.Size(209, 30);
            this.submitRecordsLabel.TabIndex = 10;
            this.submitRecordsLabel.Text = "Submit Records";
            this.submitRecordsLabel.UseVisualStyleBackColor = true;
            this.submitRecordsLabel.Click += new System.EventHandler(this.submitRecordsLabel_Click);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 273);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(441, 68);
            this.label12.TabIndex = 11;
            this.label12.Text = "Duty status:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // setDutyStatus
            // 
            this.setDutyStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.setDutyStatus.DropDownHeight = 120;
            this.setDutyStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.setDutyStatus.FormattingEnabled = true;
            this.setDutyStatus.IntegralHeight = false;
            this.setDutyStatus.ItemHeight = 13;
            this.setDutyStatus.Items.AddRange(new object[] {
            "Paid",
            "Suspended"});
            this.setDutyStatus.Location = new System.Drawing.Point(450, 296);
            this.setDutyStatus.MaxDropDownItems = 100;
            this.setDutyStatus.Name = "setDutyStatus";
            this.setDutyStatus.Size = new System.Drawing.Size(209, 21);
            this.setDutyStatus.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(441, 69);
            this.label6.TabIndex = 14;
            this.label6.Text = "Select gyle number:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // selectGyleLabel
            // 
            this.selectGyleLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.selectGyleLabel.DataSource = this.packagingDutySelectViewBindingSource1;
            this.selectGyleLabel.DisplayMember = "gyle";
            this.selectGyleLabel.DropDownHeight = 120;
            this.selectGyleLabel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectGyleLabel.FormattingEnabled = true;
            this.selectGyleLabel.IntegralHeight = false;
            this.selectGyleLabel.ItemHeight = 13;
            this.selectGyleLabel.Location = new System.Drawing.Point(450, 24);
            this.selectGyleLabel.MaxDropDownItems = 100;
            this.selectGyleLabel.Name = "selectGyleLabel";
            this.selectGyleLabel.Size = new System.Drawing.Size(209, 21);
            this.selectGyleLabel.TabIndex = 15;
            this.selectGyleLabel.ValueMember = "gyle";
            // 
            // packagingDutySelectViewBindingSource1
            // 
            this.packagingDutySelectViewBindingSource1.DataMember = "packagingDutySelectView";
            this.packagingDutySelectViewBindingSource1.DataSource = this.gu_views1;
            // 
            // gu_views1
            // 
            this.gu_views1.DataSetName = "gu_views";
            this.gu_views1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // setStartNumber
            // 
            this.setStartNumber.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.setStartNumber.Location = new System.Drawing.Point(450, 161);
            this.setStartNumber.Name = "setStartNumber";
            this.setStartNumber.Size = new System.Drawing.Size(209, 20);
            this.setStartNumber.TabIndex = 17;
            // 
            // setStaffID
            // 
            this.setStaffID.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.setStaffID.DataSource = this.gustaffBindingSource;
            this.setStaffID.DisplayMember = "last_name";
            this.setStaffID.DropDownHeight = 120;
            this.setStaffID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.setStaffID.FormattingEnabled = true;
            this.setStaffID.IntegralHeight = false;
            this.setStaffID.ItemHeight = 13;
            this.setStaffID.Location = new System.Drawing.Point(450, 92);
            this.setStaffID.MaxDropDownItems = 100;
            this.setStaffID.Name = "setStaffID";
            this.setStaffID.Size = new System.Drawing.Size(209, 21);
            this.setStaffID.TabIndex = 18;
            this.setStaffID.ValueMember = "staff_id";
            // 
            // gustaffBindingSource
            // 
            this.gustaffBindingSource.DataMember = "gu_staff";
            this.gustaffBindingSource.DataSource = this.gu_tables;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(3, 341);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(441, 69);
            this.label23.TabIndex = 19;
            this.label23.Text = "Storage location:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // updateLocationLabel
            // 
            this.updateLocationLabel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.updateLocationLabel.DataSource = this.gulocationBindingSource2;
            this.updateLocationLabel.DisplayMember = "storage_location";
            this.updateLocationLabel.DropDownHeight = 120;
            this.updateLocationLabel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.updateLocationLabel.FormattingEnabled = true;
            this.updateLocationLabel.IntegralHeight = false;
            this.updateLocationLabel.ItemHeight = 13;
            this.updateLocationLabel.Location = new System.Drawing.Point(450, 365);
            this.updateLocationLabel.MaxDropDownItems = 100;
            this.updateLocationLabel.Name = "updateLocationLabel";
            this.updateLocationLabel.Size = new System.Drawing.Size(209, 21);
            this.updateLocationLabel.TabIndex = 20;
            this.updateLocationLabel.ValueMember = "location_id";
            // 
            // gulocationBindingSource2
            // 
            this.gulocationBindingSource2.DataMember = "gu_location";
            this.gulocationBindingSource2.DataSource = this.gu_tables;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(749, 486);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Stock View";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.filledDataGridViewTextBoxColumn,
            this.dateFilledDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.packagingStockViewBindingSource3;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(746, 483);
            this.dataGridView2.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Gyle";
            this.dataGridViewTextBoxColumn25.HeaderText = "Gyle";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Drink";
            this.dataGridViewTextBoxColumn26.HeaderText = "Drink";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Container";
            this.dataGridViewTextBoxColumn41.HeaderText = "Container";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn42.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Packaged?";
            this.dataGridViewTextBoxColumn43.HeaderText = "Packaged?";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "Location";
            this.dataGridViewTextBoxColumn44.HeaderText = "Location";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            // 
            // filledDataGridViewTextBoxColumn
            // 
            this.filledDataGridViewTextBoxColumn.DataPropertyName = "Filled?";
            this.filledDataGridViewTextBoxColumn.HeaderText = "Filled?";
            this.filledDataGridViewTextBoxColumn.Name = "filledDataGridViewTextBoxColumn";
            this.filledDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateFilledDataGridViewTextBoxColumn
            // 
            this.dateFilledDataGridViewTextBoxColumn.DataPropertyName = "Date Filled";
            this.dateFilledDataGridViewTextBoxColumn.HeaderText = "Date Filled";
            this.dateFilledDataGridViewTextBoxColumn.Name = "dateFilledDataGridViewTextBoxColumn";
            this.dateFilledDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // packagingStockViewBindingSource3
            // 
            this.packagingStockViewBindingSource3.DataMember = "packagingStockView";
            this.packagingStockViewBindingSource3.DataSource = this.gu_views;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dataGridView5);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(749, 486);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "Duty Records";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.AllowUserToDeleteRows = false;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31});
            this.dataGridView5.DataSource = this.packagingDutyRecordsViewBindingSource2;
            this.dataGridView5.Location = new System.Drawing.Point(1, 2);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.Size = new System.Drawing.Size(746, 483);
            this.dataGridView5.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Gyle";
            this.dataGridViewTextBoxColumn27.HeaderText = "Gyle";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Start number";
            this.dataGridViewTextBoxColumn28.HeaderText = "Start number";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "End number";
            this.dataGridViewTextBoxColumn29.HeaderText = "End number";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn30.HeaderText = "Status";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Employee";
            this.dataGridViewTextBoxColumn31.HeaderText = "Employee";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            // 
            // packagingDutyRecordsViewBindingSource2
            // 
            this.packagingDutyRecordsViewBindingSource2.DataMember = "packagingDutyRecordsView";
            this.packagingDutyRecordsViewBindingSource2.DataSource = this.gu_views;
            // 
            // Sales
            // 
            this.Sales.Controls.Add(this.tabControl3);
            this.Sales.Location = new System.Drawing.Point(4, 22);
            this.Sales.Name = "Sales";
            this.Sales.Padding = new System.Windows.Forms.Padding(3);
            this.Sales.Size = new System.Drawing.Size(769, 521);
            this.Sales.TabIndex = 2;
            this.Sales.Text = "Sales";
            this.Sales.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage3);
            this.tabControl3.Location = new System.Drawing.Point(6, 3);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(757, 512);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.tableLayoutPanel4);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(749, 486);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Sell";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel4.Controls.Add(this.deleteRecords, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.label17, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.selectGyleSell, 1, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.00752F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.99249F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(746, 483);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // deleteRecords
            // 
            this.deleteRecords.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.deleteRecords.Location = new System.Drawing.Point(450, 347);
            this.deleteRecords.Name = "deleteRecords";
            this.deleteRecords.Size = new System.Drawing.Size(209, 30);
            this.deleteRecords.TabIndex = 10;
            this.deleteRecords.Text = "Delete Records";
            this.deleteRecords.UseVisualStyleBackColor = true;
            this.deleteRecords.Click += new System.EventHandler(this.deleteRecords_Click);
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(441, 241);
            this.label17.TabIndex = 14;
            this.label17.Text = "Select gyle number:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // selectGyleSell
            // 
            this.selectGyleSell.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.selectGyleSell.DataSource = this.salesAvailableViewBindingSource5;
            this.selectGyleSell.DisplayMember = "Gyle";
            this.selectGyleSell.DropDownHeight = 120;
            this.selectGyleSell.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectGyleSell.FormattingEnabled = true;
            this.selectGyleSell.IntegralHeight = false;
            this.selectGyleSell.ItemHeight = 13;
            this.selectGyleSell.Location = new System.Drawing.Point(450, 110);
            this.selectGyleSell.MaxDropDownItems = 100;
            this.selectGyleSell.Name = "selectGyleSell";
            this.selectGyleSell.Size = new System.Drawing.Size(209, 21);
            this.selectGyleSell.TabIndex = 15;
            this.selectGyleSell.ValueMember = "Gyle";
            // 
            // salesAvailableViewBindingSource5
            // 
            this.salesAvailableViewBindingSource5.DataMember = "salesAvailableView";
            this.salesAvailableViewBindingSource5.DataSource = this.gu_views3;
            // 
            // gu_views3
            // 
            this.gu_views3.DataSetName = "gu_views";
            this.gu_views3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(749, 486);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "View Available";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Gyle,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34});
            this.dataGridView3.DataSource = this.salesAvailableViewBindingSource4;
            this.dataGridView3.Location = new System.Drawing.Point(1, 2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(746, 483);
            this.dataGridView3.TabIndex = 2;
            // 
            // Gyle
            // 
            this.Gyle.DataPropertyName = "Gyle";
            this.Gyle.HeaderText = "Gyle";
            this.Gyle.Name = "Gyle";
            this.Gyle.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Drink";
            this.dataGridViewTextBoxColumn32.HeaderText = "Drink";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "Container";
            this.dataGridViewTextBoxColumn33.HeaderText = "Container";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn34.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            // 
            // salesAvailableViewBindingSource4
            // 
            this.salesAvailableViewBindingSource4.DataMember = "salesAvailableView";
            this.salesAvailableViewBindingSource4.DataSource = this.gu_views;
            // 
            // salesAvailableViewBindingSource3
            // 
            this.salesAvailableViewBindingSource3.DataMember = "salesAvailableView";
            this.salesAvailableViewBindingSource3.DataSource = this.gu_views2;
            // 
            // gu_views2
            // 
            this.gu_views2.DataSetName = "gu_views";
            this.gu_views2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesAvailableViewBindingSource2
            // 
            this.salesAvailableViewBindingSource2.DataMember = "salesAvailableView";
            this.salesAvailableViewBindingSource2.DataSource = this.gu_views;
            // 
            // packagingDutySelectViewBindingSource
            // 
            this.packagingDutySelectViewBindingSource.DataMember = "packagingDutySelectView";
            this.packagingDutySelectViewBindingSource.DataSource = this.gu_views;
            // 
            // gubatchBindingSource2
            // 
            this.gubatchBindingSource2.DataMember = "gu_batch";
            this.gubatchBindingSource2.DataSource = this.gu_tables;
            // 
            // gubatchBindingSource5
            // 
            this.gubatchBindingSource5.DataMember = "gu_batch";
            this.gubatchBindingSource5.DataSource = this.gu_tables;
            // 
            // packagingStockViewBindingSource2
            // 
            this.packagingStockViewBindingSource2.DataMember = "packagingStockView";
            this.packagingStockViewBindingSource2.DataSource = this.gu_views;
            // 
            // packagingStockViewTableAdapter
            // 
            this.packagingStockViewTableAdapter.ClearBeforeFill = true;
            // 
            // packagingDutyRecordsViewTableAdapter
            // 
            this.packagingDutyRecordsViewTableAdapter.ClearBeforeFill = true;
            // 
            // salesAvailableViewTableAdapter
            // 
            this.salesAvailableViewTableAdapter.ClearBeforeFill = true;
            // 
            // productionViewTableAdapter
            // 
            this.productionViewTableAdapter.ClearBeforeFill = true;
            // 
            // gu_alcaholTableAdapter
            // 
            this.gu_alcaholTableAdapter.ClearBeforeFill = true;
            // 
            // gu_storageTableAdapter
            // 
            this.gu_storageTableAdapter.ClearBeforeFill = true;
            // 
            // gu_locationTableAdapter
            // 
            this.gu_locationTableAdapter.ClearBeforeFill = true;
            // 
            // gu_batchTableAdapter
            // 
            this.gu_batchTableAdapter.ClearBeforeFill = true;
            // 
            // gubatchBindingSource3
            // 
            this.gubatchBindingSource3.DataMember = "gu_batch";
            this.gubatchBindingSource3.DataSource = this.gu_tables;
            // 
            // fKgubatchgustorageBindingSource
            // 
            this.fKgubatchgustorageBindingSource.DataMember = "FK_gu_batch_gu_storage";
            this.fKgubatchgustorageBindingSource.DataSource = this.gustorageBindingSource2;
            // 
            // gubatchBindingSource4
            // 
            this.gubatchBindingSource4.DataMember = "gu_batch";
            this.gubatchBindingSource4.DataSource = this.gu_tables;
            // 
            // fKgubatchgulocationBindingSource
            // 
            this.fKgubatchgulocationBindingSource.DataMember = "FK_gu_batch_gu_location";
            this.fKgubatchgulocationBindingSource.DataSource = this.gulocationBindingSource;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Gyle";
            this.dataGridViewTextBoxColumn21.HeaderText = "Gyle";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Drink";
            this.dataGridViewTextBoxColumn22.HeaderText = "Drink";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Container";
            this.dataGridViewTextBoxColumn23.HeaderText = "Container";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn24.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // gu_staffTableAdapter
            // 
            this.gu_staffTableAdapter.ClearBeforeFill = true;
            // 
            // gutablesBindingSource
            // 
            this.gutablesBindingSource.DataSource = this.gu_tables;
            this.gutablesBindingSource.Position = 0;
            // 
            // gudutyBindingSource
            // 
            this.gudutyBindingSource.DataMember = "gu_duty";
            this.gudutyBindingSource.DataSource = this.gu_tables;
            // 
            // gu_dutyTableAdapter
            // 
            this.gu_dutyTableAdapter.ClearBeforeFill = true;
            // 
            // gubatchBindingSource6
            // 
            this.gubatchBindingSource6.DataMember = "gu_batch";
            this.gubatchBindingSource6.DataSource = this.gu_tables;
            // 
            // gustorageBindingSource3
            // 
            this.gustorageBindingSource3.DataMember = "gu_storage";
            this.gustorageBindingSource3.DataSource = this.gu_tables;
            // 
            // packagingDutySelectViewTableAdapter
            // 
            this.packagingDutySelectViewTableAdapter.ClearBeforeFill = true;
            // 
            // packagingBottlingSelectViewTableAdapter
            // 
            this.packagingBottlingSelectViewTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.tab_control_1);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tab_control_1.ResumeLayout(false);
            this.Production.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_tables)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gualcaholBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views)).EndInit();
            this.Tab2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagingBottlingSelectViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutySelectViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustaffBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gulocationBindingSource2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource3)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource2)).EndInit();
            this.Sales.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gu_views2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutySelectViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gualcaholBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productionViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingDutyRecordsViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesAvailableViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesSoldViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.packagingStockViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKgubatchgustorageBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKgubatchgulocationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gutablesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gudutyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gubatchBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gustorageBindingSource3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tab_control_1;
        private System.Windows.Forms.TabPage Production;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage Tab2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage Sales;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox insertAlcohol;
        private System.Windows.Forms.ComboBox insertContainer;
        private System.Windows.Forms.TextBox insertGyle;
        private System.Windows.Forms.TextBox insertNumberContainers;
        private System.Windows.Forms.Button submitRecordsInsert;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox setEndNumber;
        private System.Windows.Forms.Button submitRecordsLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox setDutyStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox selectGyleLabel;
        private System.Windows.Forms.TextBox setStartNumber;
        private System.Windows.Forms.ComboBox setStaffID;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button submitRecordsBottle;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox selectGyleBottle;
        private System.Windows.Forms.ComboBox updateContainer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox updateLocationLabel;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button deleteRecords;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox selectGyleSell;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.ComboBox updateLocationBottle;
        private System.Windows.Forms.BindingSource testViewBindingSource;
        private System.Windows.Forms.BindingSource productionViewBindingSource;
        private System.Windows.Forms.BindingSource packagingViewBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyleDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn drinkDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn containerDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn packagedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource salesAvailableViewBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn drinkDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn containerDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource salesSoldViewBindingSource;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource packagingDutyRecordsViewBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn gyleDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource gubatchBindingSource;
        private System.Windows.Forms.DateTimePicker updateDate;
		private System.Windows.Forms.BindingSource gualcaholBindingSource;
		private System.Windows.Forms.BindingSource gustorageBindingSource;
		private System.Windows.Forms.BindingSource gustorageBindingSource1;
		private System.Windows.Forms.BindingSource gubatchBindingSource1;
		private System.Windows.Forms.DataGridViewTextBoxColumn gyleDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn drinkDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn aBVDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn containerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn sizemlDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource productionViewBindingSource1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
		private System.Windows.Forms.BindingSource packagingStockViewBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
		private System.Windows.Forms.BindingSource packagingDutyRecordsViewBindingSource1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
		private System.Windows.Forms.BindingSource salesAvailableViewBindingSource1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
		private System.Windows.Forms.BindingSource packagingStockViewBindingSource1;
		private gu_views gu_views;
		private System.Windows.Forms.BindingSource packagingStockViewBindingSource2;
		private gu_viewsTableAdapters.packagingStockViewTableAdapter packagingStockViewTableAdapter;
		private System.Windows.Forms.BindingSource packagingDutyRecordsViewBindingSource2;
		private gu_viewsTableAdapters.packagingDutyRecordsViewTableAdapter packagingDutyRecordsViewTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
		private System.Windows.Forms.BindingSource salesAvailableViewBindingSource2;
		private gu_viewsTableAdapters.salesAvailableViewTableAdapter salesAvailableViewTableAdapter;
		private System.Windows.Forms.BindingSource productionViewBindingSource2;
		private gu_viewsTableAdapters.productionViewTableAdapter productionViewTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
		private gu_tables gu_tables;
		private System.Windows.Forms.BindingSource gualcaholBindingSource1;
		private gu_tablesTableAdapters.gu_alcaholTableAdapter gu_alcaholTableAdapter;
		private System.Windows.Forms.BindingSource gustorageBindingSource2;
		private gu_tablesTableAdapters.gu_storageTableAdapter gu_storageTableAdapter;
		private System.Windows.Forms.BindingSource gulocationBindingSource;
		private gu_tablesTableAdapters.gu_locationTableAdapter gu_locationTableAdapter;
		public System.Windows.Forms.ComboBox insertLocation;
		private System.Windows.Forms.BindingSource gubatchBindingSource2;
		private gu_tablesTableAdapters.gu_batchTableAdapter gu_batchTableAdapter;
		private System.Windows.Forms.BindingSource gulocationBindingSource1;
		private System.Windows.Forms.TextBox updateNumberContainers;
		private System.Windows.Forms.BindingSource gubatchBindingSource3;
		private System.Windows.Forms.BindingSource fKgubatchgustorageBindingSource;
		private System.Windows.Forms.BindingSource gubatchBindingSource4;
		private System.Windows.Forms.BindingSource fKgubatchgulocationBindingSource;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
		private System.Windows.Forms.DataGridViewTextBoxColumn filledDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn dateFilledDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource packagingStockViewBindingSource3;
		private System.Windows.Forms.BindingSource gubatchBindingSource5;
		private System.Windows.Forms.BindingSource gustaffBindingSource;
		private gu_tablesTableAdapters.gu_staffTableAdapter gu_staffTableAdapter;
		private System.Windows.Forms.BindingSource gutablesBindingSource;
		private System.Windows.Forms.BindingSource gudutyBindingSource;
		private gu_tablesTableAdapters.gu_dutyTableAdapter gu_dutyTableAdapter;
		private System.Windows.Forms.BindingSource gulocationBindingSource2;
		private System.Windows.Forms.BindingSource gubatchBindingSource6;
		private System.Windows.Forms.BindingSource gustorageBindingSource3;
		private System.Windows.Forms.BindingSource packagingDutySelectViewBindingSource;
		private gu_viewsTableAdapters.packagingDutySelectViewTableAdapter packagingDutySelectViewTableAdapter;
		private System.Windows.Forms.BindingSource packagingBottlingSelectViewBindingSource;
		private gu_viewsTableAdapters.packagingBottlingSelectViewTableAdapter packagingBottlingSelectViewTableAdapter;
		private gu_views gu_views1;
		private System.Windows.Forms.BindingSource packagingDutySelectViewBindingSource1;
		private gu_views gu_views2;
		private System.Windows.Forms.BindingSource salesAvailableViewBindingSource3;
		private System.Windows.Forms.BindingSource salesAvailableViewBindingSource4;
		private System.Windows.Forms.DataGridViewTextBoxColumn Gyle;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
		private gu_views gu_views3;
		private System.Windows.Forms.BindingSource salesAvailableViewBindingSource5;
	}
}

